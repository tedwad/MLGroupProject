import pandas as pd
import itertools
from enum import Enum
from functools import partial
from typing import List, Optional

from robots import WhiteRobot, BlueRobot

robots = [WhiteRobot()]
default_plots = [robot.get_base64_plot() for robot in robots]


data = pd.read_csv('robot_data.csv',low_memory=(False))
time = data['time']
joint_s = data['S_JointAngle']
joint_l = data['L_JointAngle']
joint_u = data['U_JointAngle']
joint_r = data['R_JointAngle']
joint_b = data['B_JointAngle']
joint_t = data['T_JointAngle']
grip_force = data['GripForce']
potent = data['Potentiometer']
conv2temp = data['VFDTemp2']
conv3temp = data['VFDTemp3']
conv4temp = data['VFDTemp4']


